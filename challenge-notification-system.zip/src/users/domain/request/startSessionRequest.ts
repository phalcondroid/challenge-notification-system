export class StartSessionRequest {
  username?: string;
  password?: string;
  socialNetworkId?: string; // google games, apple games, etc...
}