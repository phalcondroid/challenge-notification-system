import { User } from "../../../shared/contracts/users/entitites/user";

export class TokenResponse {
  token: string;
  user: User
}