import { PurchaseTransaction } from "../../../shared/contracts/store/domain/entities/purchaseTransaction";

export interface PurchaseResponse {
  transaction: PurchaseTransaction
}