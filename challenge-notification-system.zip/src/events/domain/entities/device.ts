export interface Device {
  id: string;
  platform: string; // SO
  platformVersion: string;
  deviceId: string; //Physically device id
}