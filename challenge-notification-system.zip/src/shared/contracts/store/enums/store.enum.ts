export enum Store {
  apple,
  gamepass,
  google,
  steam
}