export enum ReceiptStatus {
  valid,
  invalid
}