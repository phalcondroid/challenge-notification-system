export enum TransactionStatus {
  waiting,
  done,
  failed,
}