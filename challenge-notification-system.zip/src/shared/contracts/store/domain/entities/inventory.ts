export interface Inventory {
  id: string;
  sku: string;
  name: string;
  price: number;
  createAt: Date;
  updatedAt: Date;
}