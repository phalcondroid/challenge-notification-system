export enum Locale {
  es,
  en,
  fr,
}