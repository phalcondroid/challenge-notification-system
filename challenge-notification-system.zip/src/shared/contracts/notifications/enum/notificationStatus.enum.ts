export enum NotificationStatus {
  sent,
  failed
}