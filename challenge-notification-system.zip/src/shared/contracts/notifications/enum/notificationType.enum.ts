export enum NotificationType {
  local,
  ingame,
  email,
  push,
  sms
}