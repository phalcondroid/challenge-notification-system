export enum NotificationProvider {
  malchimb,
  firebase,
  AwsSns,
  twilio,
  pusher
}