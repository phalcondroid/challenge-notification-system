export interface NotificationManager {
  
}