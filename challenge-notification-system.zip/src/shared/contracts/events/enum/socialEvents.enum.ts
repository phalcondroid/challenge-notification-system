export enum SocialEvents {
  friendRequest,
  friendRequestAccepted,
  friendRequestRejected,
  newFollower,
  online,
  offline
}