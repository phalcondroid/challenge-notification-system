export enum GameEvents {
  levelUp,
  levelDown,
  findingMatch,
  matched,
  lostMatch,
  winMatch,
  drawMatch
}