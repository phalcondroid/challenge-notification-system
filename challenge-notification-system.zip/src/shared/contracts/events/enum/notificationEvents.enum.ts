export enum NotificationEvents {
  sendPushNotification,
  sendInGameNotification
}