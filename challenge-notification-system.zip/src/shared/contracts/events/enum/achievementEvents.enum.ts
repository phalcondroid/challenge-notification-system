export enum AchievementEvents {
  challengeCompleted = "AC_1"
}