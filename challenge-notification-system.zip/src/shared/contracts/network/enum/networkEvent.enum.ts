export enum NetworkEvent {
  connectionLost,
  reconnect,
  connected,
  failedToConnect
}