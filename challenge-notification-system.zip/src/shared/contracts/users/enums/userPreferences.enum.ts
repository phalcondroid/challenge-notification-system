export enum UserPreferences {
  gameNotifications,
  socialNotifications
}