export enum UserStatus {
  online,
  offline
}