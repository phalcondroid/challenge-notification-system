
export enum AchievementType {
  passSuccessfullyTutorial,
  winFirstBattle,
  winVsAi,
  winVsHumanPlayer
}