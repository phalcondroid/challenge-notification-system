
export function post() {
  return function (target) {} 
}

export function put() {
  return function (target) {} 
}

export function patch() {
  return function (target) {} 
}

export function get() {
  return function (target) {} 
}